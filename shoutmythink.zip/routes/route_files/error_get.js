// error.ejs page.
module.exports = function(req, res) {

    console.log('/error_get path is required.');

    res.render('error_get.ejs');
    return;
}
