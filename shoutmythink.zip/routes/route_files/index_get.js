// index.ejs page.(form get).
module.exports = function(req, res) {

console.log('/ path is required.');

res.render('index.ejs');
return;
};
