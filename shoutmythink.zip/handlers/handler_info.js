console.log('handler_info 파일 로딩됨.');

module.exports = [{
    file: './handler_files/article_database_check',
    method: 'article_database_check'
}];
